var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;




/*********add data in MongoDb***********************/
exp.route('/rest/api/readfile',cors()).post((req,res)=>{
    console.log("hMMMMMMMMMMMMMMMMM");
    var dataInFile;
    fs.readFile('demo.json',function(err,data){
        res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
        //console.log(dataInFile);
        //res.send(dataInFile);
        res.end();
    });   

    MongoClient.connect('mongodb://localhost:27017/myProductdb', function(err, dbvar){
        console.log('In Mongo Client',dataInFile);
        if(err) throw err;
        var coll = dbvar.db('myProductdb');
        coll.collection('productCollection').insert(dataInFile, function(err, res){
            if(err) throw err;
            console.log('One document inserted....');
            //res.end();
            dbvar.close();
        });
        dbvar.close();
    });

});






/***********************displaying all the employeess***************************/

exp.route('/rest/api/get', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    //res.send({msg: 'GET WORLD....'});
    MongoClient.connect('mongodb://localhost:27017/myProductdb', (err, dbvar)=>{
        console.log('In Mongo Client');
        if(err) throw err;
        var coll = dbvar.db('myProductdb');
        coll.collection('productCollection').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})


/**********************displaying employees belongs to specific state**************/


exp.route('/rest/api/getState', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    //res.send({msg: 'GET WORLD....'});
    MongoClient.connect('mongodb://localhost:27017/myProductdb', (err, dbvar)=>{
        console.log('In Mongo Client');
        if(err) throw err;
        var coll = dbvar.db('myProductdb');
        coll.collection('productCollection').find({"empAddress.state":"Maharashtra"}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})



/*
exp.route('/rest/api/getState', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    //res.send({msg: 'GET WORLD....'});
    MongoClient.connect('mongodb://localhost:27017/myProductdb', (err, dbvar)=>{
        console.log('In Mongo Client');
        if(err) throw err;
        var coll = dbvar.db('myProductdb');
        coll.collection('productCollection').find({state:req.query.state}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})*/



/**********************updating city of employee**********************/
exp.use(parser.json());

exp.route('/rest/api/put',cors()).put((req,res)=>{

//console.log(req.body.empId);
//console.log(req.body.empAddress.city);

// MongoClient.connect('mongodb://localhost:27017/myProductdb', function(err, db) {
//   if (err) throw err;
//   var dbo = db.db("myProductdb");
 // var myquery = { empId: req.body.empId };
 
  //var newvalues = { $set: {empAddress:{city:req.body.empAddress.city}}};
  //db.ProductCollection.update({"_id":3},{$set:{"orderstatus":"pending"}});
//   dbo.collection("productCollection").update({ empId: req.body.empId }, {  $set:{"empAddress.city":req.body.empAddress.city}}, function(err, res) {
//     if (err) throw err;
//     console.log("1 document updated");
//     db.close();
//   });

  MongoClient.connect('mongodb://localhost:27017/myProductdb', { useNewUrlParser: true }, function(err, dbvar){
        if(err) throw err;
        var coll = dbvar.db('myProductdb');        
        coll.collection('productCollection').updateOne({empId: (req.body).empId}, {$set: {"empAddress.city": (req.body).empAddress.city}}, true, function(err, result){
            if(err) throw err;
            console.log('One document Updated....');            
            dbvar.close();
        });
        dbvar.close();
    });

});
// });



/*************************Adding new employeess****************************/

exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
   // fs.appendFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);

    MongoClient.connect('mongodb://localhost:27017/myProductdb', function (err, dbvar) {
        console.log('In Mongo Client', req.body);
        if (err) throw err;
        //database mani
        var coll = dbvar.db('myProductdb');
        //collection Mans
        coll.collection('productCollection').insert(req.body, true, function (err, res) {
            if (err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });
});

exp.use(cors()).listen(3000, () => console.log("RUNNING...."));