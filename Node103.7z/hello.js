var http = require('http');

var express = require('express');

var exp = express();

/*****************************get*****************************/
/*var x= exp.get('/get',function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h1>Hello world</h1>");
    res.end();

})
http.createServer(x).listen(3002);*/


/***********************Retrive values from parameters***********************/
var x= exp.get('/mul',function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h1>Hello world</h1>"+req.query.id);
    res.end();

})
http.createServer(x).listen(3002);



/********************************Post**********************************/
/*var x= exp.post('/submit',function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h1>Hello world</h1>");
    res.end();

})
http.createServer(x).listen(3002);*/






/*************************************************************************************************************/






/*http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h1>Hello world</h1>");
    res.end();

}).listen(3001)

var http=require('http');
var x= (req,res)=>{
    res.writeHead(200,{'Content-Type':'text/plain'});
    res.write("Hello world function");
    res.end();
}
http.createServer(x).listen(3002);
*/

