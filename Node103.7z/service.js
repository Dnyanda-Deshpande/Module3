var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;

var corsOptions = {
    origin: 'http://localhost:4200'
}


exp.get('/rest/api/load', cors(), (req, res) => {
    console.log('Load Invoked');
    res.send({ msg: 'Give Some rest to world' });
});


// exp.route('/rest/api/get', cors()).get((req, res) => {
//     console.log("Get Invoked");
//     // res.send({ msg: "World" });

//     /*var url = 'mongodb://localhost:27017/mani';
//     MongoClient.connect(url, function(err, db) {
//     var col = db.collection('Mans').find();
//     col.each(function(err, doc) {
//         res.send(doc);
//         console.log(doc);

//      });
//     }); */
//     MongoClient.connect('mongodb://localhost:27017/test', function (err, dbvar) {
//         if (err) throw err;
//         var dbo = dbvar.db("test");
//         dbo.collection("test").find().toArray(function (err, result) {
//             if (err) throw err;
//             res.send(result);
//             db.close();
//         });
//     });

// });

/***************fetch data from db************************/
exp.route('/rest/api/get', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    //res.send({msg: 'GET WORLD....'});
    MongoClient.connect('mongodb://localhost:27017/test', (err, dbvar)=>{
        console.log('In Mongo Client');
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})





/*******post data in db****************************/
exp.use(parser.json());
exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
    fs.appendFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);

    MongoClient.connect('mongodb://localhost:27017/test', function (err, dbvar) {
        console.log('In Mongo Client', req.body);
        if (err) throw err;
        //database mani
        var coll = dbvar.db('test');
        //collection Mans
        coll.collection('test').insert(req.body, true, function (err, res) {
            if (err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });
});




/*******************delete data***********************/
exp.route('/rest/api/delete',cors()).delete((req,res)=>{
    console.log((req.body));

        MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
        if (err) throw err;
        var dbo = db.db("test");
        /*Delete the first customers with the address "Mountain 21":*/
        //var myquery = { name:'dora' };
        dbo.collection("test").deleteOne(req.body, function(err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            res.end();
            db.close();
        });
        });
});

/**********************update data******************/

exp.route('/rest/api/put',cors()).put((req,res)=>{

console.log(req.body.name);
console.log(req.body.age);

MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  if (err) throw err;
  var dbo = db.db("test");
  var myquery = { name: req.body.name };
  var newvalues = { $set: {age:req.body.age} };
  dbo.collection("test").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});
});


/*******************************read json and store to monogo*****************************/

exp.route('/rest/api/readfile',cors()).post((req,res)=>{
    console.log("hMMMMMMMMMMMMMMMMM");
    var dataInFile;
    fs.readFile('demo.json',function(err,data){
        res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
        console.log(dataInFile);
        res.end();
    });
   

    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){
        console.log('In Mongo Client',dataInFile);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').insertMany(dataInFile, true, function(err, res){
            if(err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });

});

exp.route('/rest/api/get/:name').get((req, res) => {
    res.send('Hello World' + req.params['name']);
});




exp.use(cors()).listen(3000, () => console.log("RUNNING...."));