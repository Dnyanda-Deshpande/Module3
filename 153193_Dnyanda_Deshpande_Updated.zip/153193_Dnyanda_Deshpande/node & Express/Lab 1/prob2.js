var fs = require('fs');

 function readData(err, data){
	  console.log(data);
 }

fs.readFile('sample.txt', 'utf8', readData);