var employee = ["Don","Shehensha","Shakal","Mr.Inida","Prem","Fene"];


exports.getEmployee = function() {
    for(x in employee)
    {
        console.log(employee[x]);
    }
}