
/*var fs = require("fs");

var writeStream = fs.createWriteStream("sample.txt");
writeStream.write("Hi, JournalDEV Users. ");
writeStream.write("Thank You.");
writeStream.end();
*/



var fs = require('fs');

fs.appendFile('sample.txt', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});