var disp = require('./prob1');


var read = require('./prob2');
disp.getEmployee();