import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {AddTask} from '../actions/index';

class Taskbar extends React.Component{
    render(){
        return(
            <div>
                <input type='text' ref='task'/>
                <button onClick={()=>this.props.AddTask(this.refs.task.value)}>ADD TASK</button>
            </div>
        )
    }
}
function mapDispatchToProps(dispatch){
    return bindActionCreators({AddTask},dispatch)
}

function mapStateToProps(state){
return {
    task:state.task
}
}

export default connect(mapStateToProps,mapDispatchToProps)(Taskbar);