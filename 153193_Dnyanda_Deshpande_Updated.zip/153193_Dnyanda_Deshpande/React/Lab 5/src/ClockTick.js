import React, { Component } from 'react';

class ClockTick extends React.Component {
  constructor(props) {
    super(props);
    this.state = {date: new Date(), isShowingText: true};


    setInterval(() => {
      this.setState(previousState => {
        return { isShowingText: !previousState.isShowingText };
      });
    }, 1000);
  }


 

  componentDidMount() {
    this.timerID = setInterval(
      () => this.tick(),
      1000
    );
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  tick() {
    this.setState({
      date: new Date()
    });
  }

  render() {
      let display = this.state.isShowingText ? 'Capgemini' : ' IGATE';
    return (
      <div>
        <h2>{this.state.date.toLocaleTimeString()}.</h2>
        <p>{display}</p>
      </div>
    );
  }
}
export default ClockTick;



/*

class Clock extends React.Component {
  constructor(props) {
    super(props);
    this.state = {date: new Date(),name:'IGATE'};
  }

  componentDidMount() {
    this.timerID = setInterval(
      () => this.tick(),
      1000
    );
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  tick() {
    this.setState({
      date: new Date(),
      name:'Capgemini'
    });
  }

  render() {
    return (
      <div>
        <h2>It is {this.state.date.toLocaleTimeString()}.</h2>
        <p>{this.state.name}</p>
      </div>
    );
  }
}

export default Clock;*/