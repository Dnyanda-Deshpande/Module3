var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');



exp.get('/rest/api/get',cors(),(req,res)=>{
    var dataInFile;
    fs.readFile('data.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
        console.log(dataInFile);
        res.send(dataInFile);
        res.end();
    });
})

exp.get('/rest/api/getstate',cors(),(req,res)=>{
    var dataInFile;
    var block=[];
    fs.readFile('data.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            for(i=0;i<dataInFile.length;i++)
            {
                if(dataInFile[i].empAddress.state=="Maharashtra")
                {
                    block[i]=dataInFile[i];
                }
            }
             console.log(block);
           res.send(block)
        res.end();
    });
})

exp.use(parser.json());
exp.route('/rest/api/putdata/:id/:city',cors()).put((req,res)=>{
    console.log(req.params.id)
    console.log(req.params.city)

   fs.readFile('data.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            for(i=0;i<dataInFile.length;i++)
            {
                if(dataInFile[i].empId==req.params.id)
                {
                    dataInFile[i].empAddress.city=req.params.city;
                }
            }
           res.send(dataInFile)
        res.end();
    });
})

exp.route('/rest/api/post', cors()).post((req, res) => {

 fs.readFile('data.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            
    var obj={"empId":1008,"empName":"Kris","empSalary":5700,"empAddress":{"city":"Sahikago","state":"Us"}};
    dataInFile.push(obj);
    console.log(dataInFile)
    fs.writeFileSync('data.json',JSON.stringify(dataInFile))
    res.send(dataInFile)
    res.end()


/*
exp.route('/addEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        var emp = {"empId":1007,"empName":"Adam","empSalary":55000,"empAddress":{"city":"San Jose","state":"California"}}
        _fileData.push(emp);
        fs.writeFileSync("employees.json", JSON.stringify(_fileData));
        res.send(_fileData);
        res.end();
    });
})
*/
});
})


exp.use(cors()).listen(3002, () => console.log("RUNNING...."));