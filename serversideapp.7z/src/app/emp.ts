export interface Emp {
    ename:string,
    eage:number
}