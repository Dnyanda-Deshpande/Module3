import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service';
import { Book } from './book';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'app';

  constructor(private demo: MyserviceService) {

  }
  data = [];
  invokeGet() {
    this.demo.getBookList().subscribe((data) => {
      this.data = data
      console.log(data);
    })
  }
  uname: string;
  age: number;

  invokePost() {
    console.log(this.uname, this.age);
    this.demo.postData(this.uname, this.age).subscribe((data: Book) => {
    });
  }
dname:string;
  invokeDelete(){
    this.demo.deleteData(this.dname).subscribe((data) => {
      
    })
  }

 
}
