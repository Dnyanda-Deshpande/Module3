import { Component, Inject } from '@angular/core';

@Inject
export class DemoGet{

     hello(){
        console.log("Hello World");
    }
}