export interface Book {
 
    ename:string,
    eage:number
}