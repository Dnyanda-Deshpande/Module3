import { Injectable } from '@angular/core';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Book} from './book';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http: HttpClient) { }
  public _url='http://localhost:3000/rest/api/get';


  getBookList():Observable<any>{
    return this.http.get<any>(this._url);
   
  }

   postData(ename:string,eage:number):Observable<Book>{
    console.log("ENAME:"+ename);
    console.log("EAGE:"+eage);
    return this.http.post('http://localhost:3000/rest/api/post',{
      name:ename,age:eage
    });
  }

  deleteData(ename:string): Observable<any>{
    console.log("Ename: "+ename);
    return this.http.post('http://localhost:3000/rest/api/delete',{name:ename});
  }

}
