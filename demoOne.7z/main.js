/*var add = require('./lib/add');
var produ = require('./lib/products');

console.log("Welcome to Node JS");
add.addData();
add.getData();

var prodOne = new produ.prod(1001,"Mobile",991);
var prodTwo = new produ.prod(1002,"Rice",770);
var prodThree = new produ.prod(1003,"Tv",30000);

produ.set(prodOne);
produ.set(prodTwo);
produ.set(prodThree);
console.log("Before sorting.................");
produ.display();
produ.sortP();
console.log("After sorting...................");
produ.display();*/


/****************************creating buffer***********************/
//new file
/*var buff = new Buffer(18);
buff.write("Capgemini");
console.log(buff.toJSON());*/


/****************************events*************************************/
//new file
var event = require('events'); //core module of node
var myevent = new event.EventEmitter();

//register of event abc
myevent.on("abc",function(msg,msgo){
    console.log("In event abc.........",msg,msgo);
    setTimeout(function(){
        console.log("After set time out of 6 sec....");
    },6000);
});

myevent.on("bcd",function(temp){
    console.log("In bcd events",temp);
});

//calling an event
myevent.emit("abc","Capegemini...........","Good Company....");

myevent.emit("bcd","Node JS");