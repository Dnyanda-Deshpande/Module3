import React, { Component } from 'react';


class App extends Component {


  constructor(props) {
    super(props);
    this.state = { text: '', inputText: '', 
                   text1: '', emailIdTxt: '', 
                   text2: '', mobNoTxt: '', 
                   text3: '', addressTxt: '', 
                   text4: '', purposeTxt: '', 
                   text5: '', dateTxt: '', 
                   mode: 'edit' };

    this.usernameHandler = this.usernameHandler.bind(this);
    this.emailIdHandler = this.emailIdHandler.bind(this);
    this.mobileNoHandler = this.mobileNoHandler.bind(this);
    this.addressHandler = this.addressHandler.bind(this);
    this.purposeHandler = this.purposeHandler.bind(this);
    this.dateHandler = this.dateHandler.bind(this);

    this.loginHandler = this.loginHandler.bind(this);
    this.deleteHandler = this.deleteHandler.bind(this);
  }

  //handle change for username
   usernameHandler(e) {
    this.setState({ inputText: e.target.value });
  }

  //handle change for email Id
  emailIdHandler(e) {
    this.setState({ emailIdTxt: e.target.value });
  }

  //handle change for mobilenumber
  mobileNoHandler(e) {
    this.setState({ mobNoTxt: e.target.value });
  }

  //handle change for address
  addressHandler(e) {
    this.setState({ addressTxt: e.target.value })
  }

  //handle change for purpose of visit
  purposeHandler(e) {
    this.setState({ purposeTxt: e.target.value })
  }

  //handle change for date of visit
  dateHandler(e) {
    this.setState({ dateTxt: e.target.value })
  }

  //handle change for login
  loginHandler() {
    this.setState({ text: this.state.inputText, 
                    text1: this.state.emailIdTxt, 
                    text2: this.state.mobNoTxt, 
                    text3: this.state.addressTxt, 
                    text4: this.state.purposeTxt, 
                    text5: this.state.dateTxt, 
                    mode: 'view', inputText: '', 
                    emailIdTxt: '', addressTxt: '', 
                    mobNoTxt: '', purposeTxt: '', dateTxt: '' });
  }

  //handle change for delete
  deleteHandler() {
    this.setState({ mode: 'edit' });
  }




  render() {
    /******displaying the values stored in state***************/
    if (this.state.mode === 'view') {
      return (
        <div class="container">
          <h1>Customer visit Information</h1>
          <table>
          <p>Name : {this.state.text}</p>
          <p>Email Id : {this.state.text1}</p>
          <p>Mobile Number : {this.state.text2}</p>
          <p>Address : {this.state.text3}</p>
          <p>Description : {this.state.text4}</p>
          <p>Date of Visit : {this.state.text5}</p>
          <button onClick={this.deleteHandler}   class="btn btn-primary btn-block">
            Delete
          </button>
          </table>
        </div>
      );
    }



    else {
      /**********UI for registration form*******************/
      return (
        <div class="container">
          <h1>Customer Registration Form</h1>
          <table>
          <div class="form-group">
            <input type="text" onChange={this.usernameHandler} class="form-control" 
              value={this.state.inputText} placeholder="Username"/>
          </div>

          <div class="form-group">
            <input type="text" onChange={this.emailIdHandler} class="form-control" 
              value={this.state.emailIdTxt} placeholder="Email Id" />
          </div>

          <div class="form-group">
            <input type="number" onChange={this.mobileNoHandler} class="form-control" 
              value={this.state.mobNoTxt} placeholder="Mobile Number" />
          </div>

          <div class="form-group">
            <input  type="text" onChange={this.addressHandler} class="form-control" 
              value={this.state.addressTxt} placeholder="Address" />
          </div>

          <div class="form-group">
            <input  type="text" onChange={this.purposeHandler} class="form-control" 
              value={this.state.purposeTxt} placeholder="Purpose of Visit" />
          </div>

          <div class="form-group">
            <input  type="text" onChange={this.dateHandler} class="form-control" 
              value={this.state.dateTxt} placeholder="date of visit" />
          </div>

          <div class="form-group">
            <button onClick={this.loginHandler} class="btn btn-primary btn-block">
              Log In
          </button>

          </div>
          </table>
        </div>
      );
    }
  }
}

export default App;
