import React, { Component } from 'react';




class ProjectDetails extends Component {
    render() {

        return (

            <div className="abc">
                <h5>Detail {this.props.id} </h5>
                <ul>
                    <li> {this.props.detail.Duration} </li>
                    <li>{this.props.detail.Budget}</li>

                </ul>
            </div>
        );
    }
}

export default ProjectDetails;