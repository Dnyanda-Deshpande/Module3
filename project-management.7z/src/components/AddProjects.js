import React, { Component } from 'react';
import uuid from 'uuid';

class AddProject extends Component{
    constructor(){
        super();
        this.state={
            newProject:{}
        }
    }
    static defaultProps = {
        categories : ["wed design", "web development", "mobile development"]
    }

    handleSubmit(e)
    {
        if(this.refs.title.value==="")
        {
            alert("Provide the Title");
            
        }
        else
        {
            this.setState({
                newProject : {
                    id:uuid.v4(),
                    title: this.refs.title.value,
                    category: this.refs.category.value
                }
            }, function(){
                console.log(this.state);
                console.log(this.state.id);
                this.props.addProject(this.state.newProject);
            }
            );
             console.log("Submitted!!!!!"+this.refs.title.value);
             e.preventDefault();
        }

       
    }

    render(){

        let categoryOtions = this.props.categories.map(category=>{
            console.log(category);
            return <option key={category} value={category}>{category}</option>
            
        });

        return(
            <div>
                <h3>Add Project</h3>

                <form onSubmit={this.handleSubmit.bind(this)}>
                    <div>
                            <label>Title</label><br/>
                            <input type="text" ref="title"/>   
                    </div>
                    <div>
                            <label>Category</label><br/>
                            <select ref="category">{categoryOtions}</select>
                    </div><br/>
                    <input type="submit" value="submit values" />    
                </form>
            </div>
        );
    }
}

export default AddProject;