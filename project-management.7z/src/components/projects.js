import React, { Component } from 'react';
import ProjectItems from './ProjectItems';
import PropTypes from 'prop-types';
class Projects extends Component {
  deleteProject(id){
    this.props.onDelete(id);
  }
  render() {
      let projectitems;
      if(this.props.projects)
      {
          projectitems = this.props.projects.map(project=>{
              console.log(project);
              return(
                <ProjectItems key={project.title} project={project} onDelete={this.deleteProject.bind(this)}/>
                
              );
          });
      }
    return (
       
      <div className="abc">
          
            <h3>Newly Added Projects</h3>
            {projectitems}   
      </div>
    );
  }

}

 Projects.propTypes = {
    projects:PropTypes.array,
    onDelete:PropTypes.func
  }


export default Projects;
