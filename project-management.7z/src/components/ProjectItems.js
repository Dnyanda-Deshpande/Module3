import React, { Component } from 'react';
import ProjectDetails from './projectDetails';

class ProjectItems extends Component {
   deleteProject(id){
    console.log("will be deleted form project item");
    this.props.onDelete(id);
  }
  render() {
    let DetailItems;
    if (this.props.project.Details) {
      DetailItems = this.props.project.Details.map((detail, index) => {
        console.log(detail);
        console.log(this.props.project.title);
        return (
          <ProjectDetails key={this.props.project.title + index} detail={detail} id={index + 1} />

        );
      });
    }
    return (

      <div>
        <ul>
          <li>{this.props.project.id}</li>
          <li>{this.props.project.title} </li>
          <li>  {this.props.project.category}</li>
          <li> {this.props.project.projectManager} </li>

          <a href="#" onClick={this.deleteProject.bind(this,this.props.project.id)} >Delete</a>

          {DetailItems}
        </ul>
      </div>


    );
  }
}

export default ProjectItems;


