import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Projects from './components/projects';
import AddProject from './components/AddProjects';
import uuid from 'uuid';
import $ from 'jquery';
import Todos from'./components/Todos';

class App extends Component {
  constructor() {
    super();
    console.log("Executed");
    this.state = {
      projects: []
    };
  }
  componentWillMount() {
    console.log("ComponentWillMount Executed");
    this.setState({
      projects: [
        {
          id: uuid.v4(),
          title: 'Buisness Website',
          category: 'Web design',
          projectManager: "XYZ",
          Details: [{

            Duration: "5 yrs",
            Budget: "1000"
          },
          {

            Duration: "4 yrs",
            Budget: "100"
          }
          ]
        },
        {
          id: uuid.v4(),
          title: 'Social App',
          category: 'Mobile Development',
          projectManager: "ABC",
          Details: [{

            Duration: "6 yrs",
            Budget: "2000"
          },
          {

            Duration: "2 yrs",
            Budget: "200"
          }
          ]
        },
        {
          id: uuid.v4(),
          title: 'Ecoomerce',
          category: 'web development',
          projectManager: "PQR",
          Details: [{

            Duration: "7 yrs",
            Budget: "3000"
          },
          {

            Duration: "8 yrs",
            Budget: "1000"
          }
          ]
        }
      ]
    });


  }



  handleAddProject(newProj) {
    let proj = this.state.projects;
    proj.push(newProj);
    console.log(newProj);
    this.setState({ projects: proj });
  }
  handleDeleteProject(id) {
    let projects = this.state.projects;
    let index = projects.findIndex(Obj => Obj.id === id);
    projects.splice(index, 1);
    this.setState({ projects: projects });
  }
  componentDidMount() {
    this.getTodos();
  }
  getTodos() {
    $.ajax({
      url: 'https://jsonplaceholder.typicode.com/todos',
      crossDomain:true,
      tpye:'GET',
      dataType: 'jsonp',
      cache: false,
      success: function (data) {
        this.setState({ todos: data }, function () {
          console.log(this.state);
        });
      }.bind(this),
      error: function (xhr, status, err) {
        console.log(err);
      }
    });
  }


  render() {
    return (
      <div className="abc">
        <h3>My First React App</h3>
        <AddProject addProject={this.handleAddProject.bind(this)} />
        <div><Projects projects={this.state.projects} onDelete={this.handleDeleteProject.bind(this)} /></div>
        <div><Todos todos={this.state.todos}/></div>
      </div>
    );
  }
}

export default App;
