import React from 'react';

class Header extends React.Component{
    render(){
        return(
            <h1>TODO APPLICATIOn</h1>
        )
    }
}

export default Header;