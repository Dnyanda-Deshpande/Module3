/*import React from 'react';
import Screen from './screen'
const myContext=React.createContext();

class Theatre extends React.Component{

    render(){
        return(
            <myContext.Consumer>
                {(context)=>(
                    <React.Fragment>
              <p>Age: {context.state.screen1}</p>
             
            </React.Fragment>
                )}
            </myContext.Consumer>
        )
    }
}

export default Theatre;*/
/*
const Theatre = (props) => (
  <myContext.Consumer>
    {context => {
      return(
        <div>
          <h2>Profile Page of {context.screen1}</h2>
        </div>
      )
    }}
  </myContext.Consumer>
)

export default Theatre;*/



import React from 'react';

import { LocaleContext } from './screen';


class Greeting extends  React.Component {


  render() {
    
    return (
      <div>
      <LocaleContext.Consumer>
      {localeVal =>
      <React.Fragment>
        <p>Theatre name: Inox</p>
        <p>Screen name:
       <li> {localeVal.list.s1}</li>
       <li> {localeVal.list.s2}</li>
       <li> {localeVal.list.s3}</li></p>
       <p>Show times:
        <li>{localeVal.list.sh1}</li>
        <li>{localeVal.list.sh2}</li>
        <li>{localeVal.list.sh3}</li>   </p>     
       </React.Fragment>
      }
    </LocaleContext.Consumer>
    
      </div>
    );
  }
}

export default Greeting;