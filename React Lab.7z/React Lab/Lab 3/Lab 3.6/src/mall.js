/*import React, { Component } from 'react';
import Theatre from './theatre';
import MyProvider from './App';
const myContext=React.createContext();


export const Family=(props)=>(
  <div className="family">
    <Person/>
  </div>
)
class Person extends Component{

  render(){
    return(
      <div className="person">
        <myContext.Consumer>
          {(context)=>(
            <React.Fragment>
            <p>I am inside the consumer... {context.state.age}</p>
            <p>I am {context.state.name}</p>
            <button onClick={context.grow}>CLICK MEEEEEEE</button>
           </React.Fragment>
          )}
        </myContext.Consumer>
      </div>
    )
  }
}

export default Person;*/



import React from 'react';


import Greeting from './theatre'
export default () => {
  return (
    
      
       <Greeting/>
       
  )}

