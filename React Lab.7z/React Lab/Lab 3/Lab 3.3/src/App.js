import React, { Component } from 'react';


var createReactClass = require('create-react-class'); 
var ForEaChFile = createReactClass(
    {
        render:function()
        {
            const strArr = ['Dnyanda','Meghana','Sayali','Surabhi'];
            React.Children.forEach(strArr,child=>(console.log("Strings Are : "+child)));
            React.Children.forEach(strArr,child=>(console.log("Length of each String of an Array:"+child.length)));
            React.Children.forEach(console.log("Length of Array : "+strArr.length));
            React.Children.forEach(strArr,(child,index)=>(console.log("Index of Strings in an Array:"+index)));
            return(
                <div>
                   <b>Strings are :</b>{strArr.map((child)=>(<p>{child}</p>))}<br/>
                   <b>Length of Each String :</b> {strArr.map((child,index)=>(<p>{child.length}</p>))}<br/>
                     <b>Number of strings in Array : </b> {strArr.length}<br/><br/>
                     <b>Index : </b>{strArr.map((child,index)=>(<p>{child}  {index}</p>))}<br/>   
                </div>
            );
        }
    }
)


export default ForEaChFile;