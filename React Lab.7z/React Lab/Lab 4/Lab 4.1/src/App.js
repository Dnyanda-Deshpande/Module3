import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {text: '', inputText: '',text1: '', passwordText:'', mode:'edit'};
    
    this.handleChange = this.handleChange.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
    this.handleLogOut = this.handleLogOut.bind(this);
    this.handleChangePassword = this.handleChangePassword.bind(this);
  }
   

  handleChange(e) {
    this.setState({ inputText: e.target.value });
  }
   handleChangePassword(e) {
    this.setState({ passwordText: e.target.value });
  }
  
  handleLogin() {
    this.setState({text: this.state.inputText,text1: this.state.passwordText, mode: 'view',inputText:'',passwordText:''});
  }

  handleLogOut() {
       
    this.setState({mode: 'edit'});
  }

  render() {
    if(this.state.mode === 'view') {
      return (
        <div>
          <h1>Login Page</h1>
          <p>Welcome <b>{this.state.text}!</b></p>
          <button onClick={this.handleLogOut}>
            SignOut
          </button>
        </div>
      );
    }
      else{
      return (
        <div>
           <h1>Login Page</h1>
          <p>Sign In</p>
            <input
              onChange={this.handleChange}
              value={this.state.inputText}
              placeholder="enter your username"
            /><br/><br/>
            <input onChange={this.handleChangePassword}
              value={this.state.passwordText} placeholder="enter your password" /><br/><br/>
          <button onClick={this.handleLogin}>
            LogIn
          </button>
        </div>
      );
      }
}
}

export default App;
